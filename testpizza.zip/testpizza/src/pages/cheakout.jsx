import React from 'react'

export default function cheakout() {
  return (
    <div>this cheakout </div>
  )
}
