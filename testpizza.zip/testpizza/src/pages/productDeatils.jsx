import React from 'react'

export default function productDeatils() {
  return (
    <div>productDeatils</div>
  )
}
