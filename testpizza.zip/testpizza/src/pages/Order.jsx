import React from 'react'
import OrderDetails from '../componets/OrderDetails'

export default function Order() {
  return (
      <div>
          <OrderDetails />
          
          <input type='text' placeholder='please Enter Number ' /> 
          
      </div>
  )
}
