import React from "react";

export default function admin() {
  return <div>this Page aDmin DashBoard </div>;
}
